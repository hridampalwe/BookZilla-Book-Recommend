const mongoose = require("mongoose");

const UserSchema = new mongoose.Schema({
  title: String,
  series: String,
  author: String,
  characters: String,
  description: String,
  language: String,
  gernes: String,
  bookFormat: String,
  edition: String,
  publisher: String,
  rating: Number,
  isbn: Number,
  pages: Number,
  numRatings: Number,
  likedPercent: Number,
});
UserSchema.index({ title: "text" });

const books = mongoose.model("books", UserSchema);

module.exports = { bookModel: books };
