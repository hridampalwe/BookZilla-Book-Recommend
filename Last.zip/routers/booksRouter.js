const express = require("express");
const BookController = require("./../controllers/BookController");
const ScoreController = require("./../controllers/ScoreController");

const router = express.Router();

// console.log(BookController);

router.route("/getRecommendation").get(BookController.getRecommendation);
router.route("/getBook").get(BookController.getBook);
router.route("/getAllBooks").get(BookController.getAllBooks);

module.exports = router;
