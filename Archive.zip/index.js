const req = require("express/lib/request");
const mongoose = require("mongoose");
const app = require("./app");
mongoose
  .connect(
    "mongodb://127.0.0.1:27017/Book?directConnection=true&serverSelectionTimeoutMS=2000"
  )
  .then(() => {
    console.log("DB connection successful");
  });

const port = 3000;
app.listen(port, (err) => {
  if (err) console.log(err);
  else console.log(`Server on port ${port}`);
});
