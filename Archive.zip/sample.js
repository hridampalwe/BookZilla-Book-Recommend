const DB = require("monk")(
  "mongodb://127.0.0.1:27017/Book?directConnection=true&serverSelectionTimeoutMS=2000"
);
const dotenv = require("dotenv");
const mongoose = require("mongoose");
// const slugify = require("slugify");
dotenv.config({ path: "./config.env" });

mongoose
  .connect(
    "mongodb://127.0.0.1:27017/Book?directConnection=true&serverSelectionTimeoutMS=2000",
    {}
  )
  .then(() => {
    console.log("DB connection successful");
  });

// const schema = new mongoose.Schema({
//   isbn: {
//     type: Number,
//   },
//   rating: {
//     type: Array,
//   },
// });

const data = mongoose.model("recommend", schema);
module.exports = data;
// const test = new data({
//     isbn: 123,
//     rating:[{"Comedy":15}, {"Shounen":20}]
// });

// test.save();
