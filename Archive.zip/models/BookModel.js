const mongoose = require("mongoose");

const UserSchema = new mongoose.Schema({
  title: String,
  series: String,
  author: String,
  characters: String,
  description: String,
  language: String,
  gernes: String,
  bookFormat: String,
  edition: String,
  publisher: String,
  rating: Number,
  isbn: Number,
  pages: Number,
  numRatings: Number,
  likedPercent: Number,
});
UserSchema.index({ title: "text" });

const books = mongoose.model("books", UserSchema);

// const t = async (req, res) => {
//   const p = await books.find();
//   console.log(p);
// };

// t();

module.exports = { bookModel: books, bookSchema: UserSchema };
