const express = require("express");
require("dotenv").config();
const path = require("path");
const monk = require("monk");
const { toUSVString } = require("util");
const mongoose = require("mongoose");
const tfidf = require("natural");
const { TfIdf } = require("natural");
const Vector = require("vector-object");
const { query } = require("express");

const booksRouter = require("./routers/booksRouter");

const app = express();
app.use(express.json());
// const book_data = db.get("books");

// Routes

app.use(function (req, res, next) {
  // Website you wish to allow to connect
  res.setHeader("Access-Control-Allow-Origin", "http://localhost:3000");

  // Request methods you wish to allow
  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST, OPTIONS, PUT, PATCH, DELETE"
  );

  // Request headers you wish to allow
  res.setHeader(
    "Access-Control-Allow-Headers",
    "X-Requested-With,content-type"
  );

  // Set to true if you need the website to include cookies in the requests sent
  // to the API (e.g. in case you use sessions)
  res.setHeader("Access-Control-Allow-Credentials", true);

  // Pass to next layer of middleware
  next();
});
app.use(express.json());
app.use(express.static(`${__dirname}/public`, { index: "overview.html" }));
app.use("/", booksRouter);

module.exports = app;
// app.get("/getBook", async (req, res) => {
//   const books_found = await fuzzy.search(req.query.keyword);
//   // console.log(books_found);
//   res.set({
//     "Access-Control-Allow-Origin": "*",
//   });
//   res.json({
//     books: books_found,
//   });
// });

let arr2 = [];

const getdata = async () => {
  const t = await book_data.find();
  let arr = [];
  t.forEach((element) => {
    let tempobj = {};
    var services = element.genres;
    services = services.split(",");
    services[0] = services[0].substring(1);
    services[services.length - 1] = services[services.length - 1].substring(
      0,
      services[services.length - 1].length - 1
    );
    services.forEach((x, i) => {
      services[i] = services[i].includes("'")
        ? services[i].replaceAll("'", "").trim()
        : services[i].toLowerCase();
    });
    tempobj = { id: element.isbn, content: services.join(" ") };
    if (tempobj.id) arr.push(tempobj);
    // else console.log(element.title);
  });
  // console.log(arr[0]);
  // arr2 = arr;
  return arr;
};

// Cosine Similarity

const createVectorsFromDocs = (processedDocs) => {
  const tfidf = new TfIdf();

  processedDocs.forEach((processedDocument) => {
    tfidf.addDocument(processedDocument.content);
  });

  const documentVectors = [];

  for (let i = 0; i < processedDocs.length; i += 1) {
    const processedDocument = processedDocs[i];
    const obj = {};

    const items = tfidf.listTerms(i);

    for (let j = 0; j < items.length; j += 1) {
      const item = items[j];
      obj[item.term] = item.tfidf;
    }

    const documentVector = {
      id: processedDocument.id,
      vector: new Vector(obj),
    };

    documentVectors.push(documentVector);
  }
  return documentVectors;
};

const calcSimilarities = (docVectors) => {
  // number of results that you want to return.
  const MAX_SIMILAR = 15;
  // min cosine similarity rating that should be returned.
  const MIN_SCORE = 0.6;
  const data = {};
  for (let i = 0; i < docVectors.length; i += 1) {
    const documentVector = docVectors[i];
    const { id } = documentVector;
    data[id] = [];
  }

  //console.log(docVectors.length);
  for (let i = 0; i < docVectors.length; i += 1) {
    for (let j = 0; j < i; j += 1) {
      if (j % 1000 == 0) console.log(`${i} Pass`);
      const idi = docVectors[i].id;
      const vi = docVectors[i].vector;
      const idj = docVectors[j].id;
      const vj = docVectors[j].vector;
      const similarity = vi.getCosineSimilarity(vj);
      if (similarity > MIN_SCORE) {
        data[idi].push({ id: idj, rating: similarity });
        data[idj].push({ id: idi, rating: similarity });
      }
    }
  }

  // finally sort the similar documents by descending order
  Object.keys(data).forEach(async (id) => {
    data[id].sort((a, b) => b.rating - a.rating);

    if (data[id].length > MAX_SIMILAR) {
      data[id] = data[id].slice(0, MAX_SIMILAR);
      const test = new d({
        isbn: id,
        rating: data[id],
      });
      await test.save();
    }
  });
  return data;
};

const getSimilarDocuments = (id, trainedData) => {
  let similarDocuments = trainedData[id];

  if (similarDocuments === undefined) {
    return [];
  }

  return similarDocuments;
};

const t = async () => {
  try {
    const po = await getdata();
    console.log(po);
    const store = createVectorsFromDocs(po);
    // console.log(store);
    const op = calcSimilarities(store);
    console.log("finish");
    // console.log(op);
    // const res = getSimilarDocuments(9780439023481, op);
    // console.log(res);
  } catch (err) {
    console.log(err);
  }
};
// t();

// app.get("/", async (req, res) => {
//   res.set({
//     "Access-Control-Allow-Origin": "*",
//   });
//   res.sendFile(path.join(__dirname, "index.html"));
// });

// app.get("/getAllBooks", async (req, res) => {
//   const limit = 5;
//   let skip = limit * parseInt(req.query.page || 1);
//   const booksListdata = await book_data.find(
//     {},
//     {
//       fields: {
//         isbn: 1,
//         title: 1,
//         rating: 1,
//         numRatings: 1,
//         genres: 1,
//         series: 1,
//         author: 1,
//         description: 1,
//         language: 1,
//         characters: 1,
//         book_format: 1,
//         edition: 1,
//         pages: 1,
//         publisher: 1,
//         publishDate: 1,
//         awards: 1,
//         ratingByStars: 1,
//         likedPercent: 1,
//         setting: 1,
//         coverImg: 1,
//         price: 1,
//       },
//       limit: 50,
//       skip,
//       sort: { _id: 1 },
//     }
//   );
//   res.set({
//     "Access-Control-Allow-Origin": "*",
//   });
//   res.json({
//     booksListdata,
//   });
// });

// app.get("/getRecommendation", async (req, res) => {
//   const limitofbooks = 12;

//   // console.log(recommendadtion);
//   // console.log(req.query.isbn);
//   const poi = await d.find({
//     isbn: req.query.isbn * 1,
//   });
//   let arr = [];
//   // console.log(poi);
//   if (poi.length != 0) {
//     poi[0].rating.forEach((obj) => {
//       arr.push(obj.id * 1);
//     });
//   }
//   // console.log(arr);
//   const opi = await book_data.aggregate(
//     // isbn: { $in: arr },
//     [
//       {
//         $match: {
//           isbn: {
//             $in: arr,
//           },
//         },
//       },
//       {
//         $limit: 8,
//       },
//     ]
//   );
//   let k = limitofbooks - opi.length;
//   let recommendadtion = await book_data.aggregate([
//     {
//       $match: {
//         // "rating": { $eq: { $type: "number" } },
//         // "numRatings": { $eq: { $type: "number" } },
//         //"genres": (req.query.genres),
//         _id: { $ne: monk.id(req.query._id) },
//       },
//     },
//     {
//       $project: {
//         isbn: 1,
//         title: 1,
//         rating: 1,
//         numRatings: 1,
//         genres: 1,
//         series: 1,
//         author: 1,
//         description: 1,
//         language: 1,
//         characters: 1,
//         book_format: 1,
//         edition: 1,
//         pages: 1,
//         publisher: 1,
//         publishDate: 1,
//         awards: 1,
//         ratingByStars: 1,
//         likedPercent: 1,
//         setting: 1,
//         coverImg: 1,
//         price: 1,
//         genres: 1,
//         result0: {
//           $convert: {
//             input: "$rating",
//             to: "double",
//             onError: "An error occurred",
//             onNull: 0,
//           },
//         },
//         result1: {
//           $convert: {
//             input: "$numRatings",
//             to: "double",
//             onError: "An error occurred",
//             onNull: 0,
//           },
//         },
//       },
//     },
//     {
//       $project: {
//         isbn: 1,
//         title: 1,
//         rating: 1,
//         numRatings: 1,
//         genres: 1,
//         series: 1,
//         author: 1,
//         description: 1,
//         language: 1,
//         characters: 1,
//         book_format: 1,
//         edition: 1,
//         pages: 1,
//         publisher: 1,
//         publishDate: 1,
//         awards: 1,
//         ratingByStars: 1,
//         likedPercent: 1,
//         setting: 1,
//         coverImg: 1,
//         price: 1,
//         genres: 1,
//         distance: {
//           $sqrt: {
//             $add: [
//               {
//                 $pow: [
//                   { $subtract: [Number(req.query.rating), "$result0"] },
//                   2,
//                 ],
//               },
//               {
//                 $pow: [
//                   { $subtract: [Number(req.query.numRatings), "$result1"] },
//                   2,
//                 ],
//               },
//             ],
//           },
//         },
//       },
//     },
//     {
//       $match: {
//         distance: { $ne: null },
//       },
//     },
//     {
//       $sort: { distance: 1 },
//     },
//     {
//       $limit: k,
//     },
//   ]);
//   // recommendadtion = Object.assign(recommendadtion, opi);
//   // console.log(opi);
//   recommendadtion = opi.concat(recommendadtion);
//   // console.log(recommendadtion.length);
//   // console.log(recommendadtion.length);
//   // console.log(recommendadtion);
//   res.set({
//     "Access-Control-Allow-Origin": "*",
//   });
//   res.json({
//     recommendadtion,
//   });
// });

// const port = 3000;
// app.listen(port, (err) => {
//   if (err) console.log(err);
//   else console.log(`Server on port ${port}`);
// });
